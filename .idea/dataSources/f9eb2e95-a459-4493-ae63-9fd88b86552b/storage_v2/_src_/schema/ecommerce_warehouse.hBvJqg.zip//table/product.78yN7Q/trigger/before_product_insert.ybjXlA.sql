create definer = root@localhost trigger before_product_insert
    before insert
    on product
    for each row
BEGIN
    SET NEW.code = CONCAT('P', LPAD(IFNULL((SELECT MAX(id) FROM product), 0) + 1, 5, '0'));
END;

